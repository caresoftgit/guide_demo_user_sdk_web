# Caresoft Customer Voice Web SDK

SDK TypeScript cho ứng dụng khách hàng trên trình duyệt: đăng nhập, kiểm tra sẵn sàng,
gọi đầu số CSKH do ứng dụng cấu hình, nhận cuộc gọi khi tab còn mở, mute, chọn đầu ra
nếu trình duyệt hỗ trợ, DTMF, reconnect và kết thúc local. Giao diện cuộc gọi có sẵn
ở entry `@caresoft/customer-voice-web/ui`, không cần React/Vue hoặc xây lại màn hình.

Phiên bản **0.1.1**. Cài gói `.tgz` trong [bộ demo/hướng dẫn](https://github.com/caresoftgit/guide_demo_user_sdk_web); không cần npm registry riêng.
Gateway cần hỗ trợ Web 0.4.1; không dùng Web SDK với backend chỉ hỗ trợ iOS/Android.

## Phát triển source

Node 22.22+ hoặc Node 24 LTS, npm và Internet để cài dependency:

```sh
npm ci
npm test
npm run build
npm pack
```

- `src/client.ts`: session/call lifecycle, readiness và quan sát trạng thái.
- `src/api.ts`: bearer HTTP, single-flight refresh, authenticated fetch SSE.
- `src/media.ts`: LiveKit browser audio, mute và đầu ra thiết bị.
- `src/ui.ts`: Web Component màn hình gọi vào/ra/đàm thoại/reconnect.
- `src/session.ts`: lưu phiên theo tab khi ứng dụng bật tùy chọn này.
- `test/`: kiểm thử session, race, recovery và media adapter.
- `docs/`: API, khả năng trình duyệt và lịch sử phiên bản.

[API](docs/api.md) · [Trình duyệt và giới hạn](docs/compatibility.md) ·
[Release notes](docs/releases.md) ·
[Demo và tích hợp](https://github.com/caresoftgit/guide_demo_user_sdk_web)

Không lưu account API token/media token vào browser storage/URL/log. SDK mặc định
giữ phiên ở memory. Khi bật sessionPersistence:tab, access/refresh token phiên
được lưu trong sessionStorage để xác minh lại sau F5. Ứng dụng production cấp
phiên từ backend đã xác thực khách hàng; form token thủ công chỉ dành demo test.

Web không có CallKit/Android Telecom, không đánh thức tab đã đóng và không bảo đảm
nhận cuộc gọi khi hệ điều hành đóng băng trình duyệt. Đợt này chưa có Web Push.

Origin website được vận hành gateway khai báo tại `cors.allowed_origins`. Web không cần dòng cấu hình push.
