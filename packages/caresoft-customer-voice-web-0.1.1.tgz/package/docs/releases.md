# Release notes

## 0.1.1 — 2026-11-19

- Tích hợp gateway 0.4.1: cấu hình CORS ở backend, không tạo push config Web.
- Hiển thị riêng mất mạng/reconnect kênh điều khiển và media.
- Chặn gọi mới khi offline, giữ phiên chờ xác minh.
- Opt-in giữ session theo tab, restore/refresh sau F5; default SDK vẫn memory.
- Web Locks tách tab nhân bản; logout/thu hồi xóa session đã lưu.
- Cảnh báo F5 khi gọi, dọn cuộc gọi cũ cả khi phản hồi đến muộn.

## 0.1.0 — bản Web ban đầu

- Core TypeScript dùng chung nghiệp vụ session/call với iOS/Android, gateway chung.
- Phiên Web, bearer fetch SSE, single-flight refresh và session fence.
- UI cuộc gọi tái sử dụng, ringing/autoplay gesture, mute, output capability, DTMF.
- Reconnect cùng call với watchdog 30s; local end đóng UI và dừng capture ngay.
- Không persist account/session/media credential; host cấp phiên từ backend.
- Demo chỉ có Gọi CSKH theo đầu số cấu hình, login/logout; không có agent status/dialer.
- Nhận khi tab còn mở/nền best effort. Web Push khi tab đóng nằm ngoài bản này.

Phân phối qua gói `.tgz` trong repo demo/hướng dẫn. Kiểm thử trên thiết bị và môi trường tích hợp theo checklist đi kèm.
