# Third-party notices

LiveKit client JS 2.24.1 (Apache-2.0) và các dependency được khai báo trong
package-lock.json. SDK không đóng gói lại media server hoặc SIP stack. Giữ thông
báo bản quyền/giấy phép dependency khi phân phối ứng dụng. TypeScript/Vitest/jsdom
chỉ dùng phát triển và kiểm thử; không là dependency runtime của gói SDK.
