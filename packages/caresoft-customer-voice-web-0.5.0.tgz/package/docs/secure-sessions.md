# Tích hợp phiên Voice bảo mật trên Web

Ứng dụng doanh nghiệp sở hữu đăng nhập/SSO. Backend đã biết `user_id` Caresoft của người dùng đang đăng nhập; chỉ backend giữ integration credential và Customer REST token. Browser nhận ticket một lần gắn PKCE S256, không nhập ID khách hàng hoặc API token.

## Cấu hình công khai

```ts
import { CustomerVoice } from '@caresoft/customer-voice-web';
import { installCustomerVoiceUi } from '@caresoft/customer-voice-web/ui';

const voice = new CustomerVoice({
  backendUrl: 'https://voice.example.com',
  accountId: 'ACCOUNT_ID',
  appId: 'CARESOFT_APP_ID',
  applicationId: location.origin,
});
const ui = installCustomerVoiceUi(voice, { supportName: 'Chăm sóc khách hàng' });
```

Thay placeholder bằng dữ liệu Caresoft cấp; Account ID là chuỗi số dương. Một instance ổn định cho ứng dụng trong tab. Website và gateway phải có HTTPS/WSS, exact origin được phép. Không truyền secret vào constructor/config.

## Dùng phiên đăng nhập sẵn có của ứng dụng

Backend doanh nghiệp triển khai endpoint ticket riêng. Ví dụ cùng origin, dùng cookie phiên hiện tại và CSRF token của ứng dụng:

```ts
const preparation = await voice.prepareLogin();
const response = await fetch('/api/voice/bootstrap', {
  method: 'POST', credentials: 'same-origin', cache: 'no-store', redirect: 'error',
  headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': applicationCsrfToken },
  body: JSON.stringify({
    attempt_id: preparation.attemptId,
    installation_id: preparation.installationId,
    os: preparation.platform,
    application_id: preparation.applicationId,
    push_environment: preparation.pushEnvironment,
    code_challenge: preparation.codeChallenge,
    code_challenge_method: preparation.codeChallengeMethod,
  }),
});
if (!response.ok) throw new Error('BOOTSTRAP_FAILED');
const ticket = await response.json();
if (ticket.attempt_id !== preparation.attemptId) throw new Error('ATTEMPT_MISMATCH');
await voice.loginWithTicket(preparation.attemptId, ticket.login_ticket);
```

`applicationCsrfToken` do ứng dụng cung cấp. Nếu dùng bearer, thay request bằng HTTP client đã xác thực của ứng dụng; đó là bearer doanh nghiệp, không phải credential Caresoft. Khi backend trả 401, xử lý đăng nhập lại theo luồng ứng dụng, không tạo form riêng trong SDK.

Preparation Web có `platform=web`, `applicationId=location.origin`, `pushEnvironment=default`. SDK giữ verifier trong memory, không trả trong preparation, không ghi storage hoặc gửi tới backend doanh nghiệp. Preparation mới không ngắt cuộc gọi hiện tại. Attempt tối đa 120 giây; ticket server mặc định 60 giây và dùng một lần. Exchange có kết quả không rõ thì tạo preparation/ticket mới, không dùng lại ticket hoặc fallback API token.

Backend xác thực phiên/CSRF/Origin, lấy ID từ principal server, kiểm tra Account/App/origin và gọi API cấp ticket Caresoft bằng credential server. Endpoint browser chỉ trả `{attempt_id, login_ticket, expires_at}` và `Cache-Control: no-store`. Không nhận `user_id` hoặc `host_session_ref` từ browser. Gateway kiểm tra quyền truy cập khách hàng và credential theo scope. Xem [payload server-to-server và luồng đầy đủ](https://github.com/caresoftgit/guide_demo_user_sdk_web).

## Sẵn sàng gọi

Gọi `prepareAudio()` từ click/tap, sau đó `checkReadiness()`. Dùng `canCall`/`canReceive` để điều khiển UI; chỉ việc đăng nhập thành công chưa chứng minh đã sẵn sàng thoại. SDK tự kết nối SSE có Bearer trong header, không đặt token trong URL. Chỉ gọi đầu số ứng dụng được cấp.

## Refresh và lưu phiên

Access thường có hạn 15 phút. SDK refresh single-flight, ghi UUID trước khi gửi và retry cùng UUID trong cửa sổ 30 giây nếu mất response, kể cả restore theo tab. Quá cửa sổ yêu cầu bootstrap mới. Rotation không kéo dài hạn tuyệt đối `sessionExpiresAt`; hạn này còn bị giới hạn bởi phiên doanh nghiệp và chính sách server.

Mặc định token ở memory. `sessionPersistence: 'tab'` bật sessionStorage và Web Locks để ngăn tab nhân bản chiếm phiên. Khởi tạo trang gọi `restoreSession()` rồi kiểm tra readiness; offline có thể giữ phiên UNKNOWN. Không dùng localStorage hoặc fallback cookie credential cho gateway. Browser token không được bảo vệ như credential ở phần cứng; cần XSS/CSP controls.

Tự nhiên hết hạn: dừng tạo/nhận cuộc gọi mới; cuộc gọi thuộc phiên đang ACTIVE có thể kết thúc bằng capability giới hạn snapshot/hangup/media-token tới deadline server. Thu hồi rõ ràng/disable đóng media. Capability không thay bearer chung. F5 không phục hồi nguyên media của cuộc gọi cũ.

## Ngắt Voice và đăng xuất ứng dụng

`await voice.logout()` dọn media, token và preparation local ngay rồi cố thu hồi phiên Voice hiện tại. Nó không đăng xuất tài khoản doanh nghiệp. Có thể kết nối lại bằng ticket mới khi phiên ứng dụng còn hợp lệ.

Khi ứng dụng đăng xuất, thực hiện cả SDK logout và cơ chế logout doanh nghiệp hiện có, xử lý lỗi từng bước và tuần tự hóa chuyển tài khoản để thao tác gắn với đúng phiên cũ. Backend vô hiệu hóa phiên doanh nghiệp và ghi outbox HOST-revoke bền vững, retry tới khi gateway xác nhận cleanup; browser không thay thế outbox này. Logout offline đơn thuần không bảo đảm thu hồi server ngay. Không tự khôi phục token local đã xóa.

## Bảo vệ

Dùng TLS/HTTPS cho API, WSS và DTLS-SRTP cho media; PKCE không mã hóa JSON hoặc chứng thực thiết bị. Cấu hình exact CORS và CSRF cho backend ứng dụng theo cơ chế cookie/bearer được chọn. Gateway requests của SDK bỏ cookie, từ chối redirect và tắt cache. Không log ticket/verifier/password/bearer/media token hoặc đưa vào URL/analytics/crash report.

Legacy `login`, `loginParameters` và `adoptSession` chỉ giữ tương thích; tích hợp mới dùng ticket PKCE. [API](api.md) và [giới hạn trình duyệt](compatibility.md).
