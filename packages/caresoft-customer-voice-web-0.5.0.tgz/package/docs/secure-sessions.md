# Secure sessions 0.5.0

The enterprise backend authenticates the customer and resolves their Caresoft ID. Only that backend holds the integration credential and Customer REST token. The browser receives a one-use ticket bound to PKCE S256. Customer ID is never an editable login field.

```ts
const preparation = await voice.prepareLogin();
// Your enterprise session authenticates this request. Handle CSRF if using cookies.
const ticket = await enterprise.bootstrap({
  attempt_id: preparation.attemptId,
  installation_id: preparation.installationId,
  os: preparation.platform,
  application_id: preparation.applicationId,
  push_environment: preparation.pushEnvironment,
  code_challenge: preparation.codeChallenge,
  code_challenge_method: preparation.codeChallengeMethod,
});
if (ticket.attempt_id !== preparation.attemptId) throw new Error('STALE_BOOTSTRAP');
await voice.loginWithTicket(preparation.attemptId, ticket.login_ticket);
```

`prepareLogin()` retains current media/session and supersedes only the pending preparation. Verifier stays in SDK memory; it is never in the preparation, storage, URL or logs. Pending attempt expires locally after 120 seconds; server ticket TTL is 60 seconds and one-use. On an unknown exchange outcome, obtain a new preparation/ticket; never fallback to legacy `login(userId, token)`.

Access tokens normally last 15 minutes. The SDK refreshes once per concurrent set of requests, with a persistent UUID recorded before transmission. A lost refresh response retries the same refresh token/UUID within 30 seconds, including opt-in tab restore. Past that window the SDK requests a new login. Rotation never extends absolute `sessionExpiresAt`.

Default storage is memory. `sessionPersistence: 'tab'` opts into sessionStorage plus Web Locks to reject duplicated-tab ownership; no localStorage or cookie credential fallback. Browser tokens are accessible to JavaScript; use CSP, trusted dependencies and XSS controls. Never claim browser storage has native Keychain security.

At natural session expiry, new/incoming calls stop. An existing owned ACTIVE call may finish using only its bounded call capability on GET call snapshot, POST hangup and POST media-token. Explicit revoke/disable stops media. Closing/reloading the browser does not restore active media. Capability is never a general API credential.

Logout clears local media, credential state and preparation immediately, then attempts server revoke. Also logout the enterprise session: its backend must atomically invalidate the host session and write a durable HOST-revoke outbox, retrying until the gateway confirms cleanup. Offline client logout alone cannot promise immediate server revocation.

Use HTTPS/WSS. Provision the web Origin for the app at the gateway and configure exact CORS/CSRF policy on the enterprise endpoint. `applicationId` is the page Origin, not proof of identity. The SDK's gateway requests omit cookies, reject redirects and disable cache.

Legacy `login`, `loginParameters`, and advanced `adoptSession` remain compatibility APIs, not the recommended integration. Native RN/Flutter token rules do not imply browser tokens can be hidden from JavaScript.
