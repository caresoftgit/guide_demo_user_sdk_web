# Caresoft Customer Voice Web SDK

SDK TypeScript **0.5.0** cho ứng dụng khách hàng trên trình duyệt: kết nối Voice bằng ticket PKCE, readiness, gọi/nhận, mute, đầu ra âm thanh, DTMF và reconnect. UI cuộc gọi có sẵn tại `@caresoft/customer-voice-web/ui`, không phụ thuộc React/Vue.

Khách hàng đăng nhập ứng dụng doanh nghiệp bằng cơ chế sẵn có. Backend doanh nghiệp lấy `user_id` Caresoft từ principal đã xác thực, cấp ticket một lần; SDK đổi ticket bằng verifier riêng. SDK không nhận username/password doanh nghiệp và không cần API token Caresoft trong browser.

Bắt đầu với [hướng dẫn phiên bảo mật](docs/secure-sessions.md), [API](docs/api.md), [trình duyệt](docs/compatibility.md) hoặc [bộ demo/tích hợp](https://github.com/caresoftgit/guide_demo_user_sdk_web). Gateway phải hỗ trợ Web và `auth_protocol=2`.

## Cài gói

```sh
npm install ./caresoft-customer-voice-web-0.5.0.tgz
```

Gói `.tgz` và SHA-256 nằm trong bộ demo. Tích hợp ứng dụng đã xác thực theo tài liệu trước khi thử gọi.

## Phát triển source

Node 22.22+ hoặc Node 24 LTS:

```sh
npm ci
npm test
npm run build
npm pack
```

| Thành phần | Nội dung |
|---|---|
| `src/client.ts` | Session/call lifecycle và readiness |
| `src/api.ts` | Bearer HTTP, single-flight refresh và authenticated fetch SSE |
| `src/media.ts` | WebRTC audio, mute và đầu ra |
| `src/ui.ts` | Web Component UI cuộc gọi |
| `src/session.ts` | Lưu phiên Voice theo tab khi ứng dụng bật tùy chọn |
| `test/` | Hồi quy session/race/recovery/media |

SDK mặc định giữ token Voice trong memory. `sessionPersistence: 'tab'` lưu access/refresh token trong sessionStorage để xác minh lại sau F5; không lưu vào localStorage. Không đưa account API token, credential tích hợp, Customer REST token hoặc media token vào browser storage, URL hay log. JavaScript cùng origin vẫn đọc được token phiên: ứng dụng cần CSP, phòng chống XSS và dependency tin cậy.

Origin website phải được đăng ký với Caresoft. Web không cần push token, không có Web Push và không bảo đảm nhận khi browser đóng băng/đóng tab. Nghiệm thu âm thanh và trình duyệt thực tế theo checklist trong bộ demo.

[Lịch sử phiên bản](docs/releases.md)
